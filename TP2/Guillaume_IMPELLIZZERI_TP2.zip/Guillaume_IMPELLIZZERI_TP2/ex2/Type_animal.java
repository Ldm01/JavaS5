package fr.tp2.ex2;

public enum Type_animal {
	CHIEN, CHAT, POISSON
}
